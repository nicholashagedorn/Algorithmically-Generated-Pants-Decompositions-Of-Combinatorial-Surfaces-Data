from surfaces import *
from collections import deque
from rich import print
import copy

generator = Pants_Decomposition()
class Greedy_Decomposition():
    def __init__(self) -> None:
        pass
        self.i = 0
        
    def rewrite_surface(self, surface):
        d = dict()
        c = 1
        m = -1
        for part_index, part in enumerate(surface.info):
            for i, v in enumerate(part):
                
                if v < 0 and v not in d:
                    d[v] = m
                    m -= 1
                
                if v >= 0 and v not in d:
                    d[v] = c
                    c += 1
                    
                surface.info[part_index][i] = d[v]
                
        surface.max = c
        surface.min = m
        
        return surface
                    
    
     # buser cut algorithm but 
    # a) two boundary components in the same connected parts AND are same boundary component
    # b) the algorithm requires you specify coordinates of the boundary component edge in the connected part
    def buser_cut_four_same_bc(self, surface, part_index_of_four):

        # part_index_of_four = the index of the connected part [x, b, y, b] where b is negative
        
        surface = self.rewrite_surface(surface)

        print(f"Running buser_cut_four_same_bc method on surface with genus {surface.genus()}")
        
        b = sorted(surface.info[part_index_of_four])[0] # the value of b in the connected part [x, b, y, b]
        
        val_to_index = generator.make_D(surface.info) # a generic dictionary to convert values to indices
        
        part_index1 = None
        
        # goal: find a connected part that neighbors a connected part in the chain
        # such a connected part must have two of b and must neighbor a connected part of length two and two of b
        for k, part in enumerate(surface.info): # look through all cp
            if len(part) != 4 and part.count(b) >= 2:  # preliminary check to save time
                
                # o are edges in the current connected part
                # here we look at all of the potential neighbors of cp k
                for o_index, o in enumerate(surface.info[k]):
                    if o < 0: continue
                
                    for other in val_to_index[o]:
                        if other[0] == k: # a routine check to ensure we get the other value
                            continue
                        # a = index of new potential connected part
                        a = other[0]
                        if len(surface.info[a]) != 4: continue
                        if surface.info[a].count(b) != 2:continue
                        
                        if part_index1 != None:
                            part_index2 = k
                            o2 = o_index
                            continue
    
                        # part_index is the index of the "mouth" to the chain
                        part_index1 = k
                        o1 = o_index
        
        # we now have coordinates of the two "mouth"s of the chain (NOTE: error if one cp is both mouths)
        # the next goal is to construct out new surface given this information

        new_surface = []
        
        # we first delete all cps in the chain and convert all b into surface.min - 1
        for new_part_index, new_part in enumerate(surface.info):
            if part_index1 == new_part_index or part_index2 == new_part_index: continue
            
            # NOTE: error here if the chain separates then comes back together
            if len(new_part) == 4 and new_part.count(b) == 2: continue
            
            new_surface.append(list(map(lambda x: (surface.min - 1) if (x==b) else x, new_part)))
        
        # create the two feeders into the head 
        main1 = [[surface.min - 1] + surface.info[part_index1][(o1+2) % len(surface.info[part_index1]) :o1-1]]
        main2 = [[surface.min - 1] + surface.info[part_index2][(o2+2) % len(surface.info[part_index2]):o2-1]]
        
        final = main1 + main2 + new_surface
        
        """print(f"Here is what it looks like before substitution: {final}")"""
        
        # Right now both of the cuts are labeled with the same boundary component
        # The final goal is to remedy this
        
        val_to_index2 = generator.make_D(final) # a new val_to_index for the new version of the surface
        
        k = "start"
        
        # we start at the boundary component at final[0][0], which is the surface.min-1 in main1
        # we loop through them to turn all of the ones that connect to this into surface.min-2
        while k != 0:
            if k == "start":
                k = 0
                place = -1
                
            place = (place + 1) % len(final[k])
            
            if final[k][place] != surface.min -1:
                raise Exception
            final[k][place] = surface.min - 2
            
            place = (place + 1) % len(final[k])
            
            for other in val_to_index2[final[k][place]]:
                if other[0] == k:
                    continue
                
                k = other[0]
                place = other[1]
                break
        
        """print(f"Here is the final pre-shorten: {final}")"""

        generator.shorten_buser_cut(final)    
        l = generator.count_length(final, surface.min - 1)
        
        s = Orientable_Bounded_Combinatorial(final, surface.max, surface.min - 1)
        
        """print(f"Here is the final post-shorten: {s}")"""

        return [s], l
    
    # buser cut algorithm but 
    # a) two distinct boundary components in the same connected parts and 
    # b) the algorithm requires you specify coordinates of the boundary component edge in the connected part
    def buser_cut_modified(self, surface, part_index):
        
        b1, b2 = (sorted(surface.info[part_index])[k] for k in [0, 1])
        
        i = surface.info[part_index].index(b1)
        j = surface.info[part_index].index(b2)
        i, j = min(i, j), max(i, j)  
        
        new_surface = []
        
        print("Now doing buser_cut_modified")
        print("Checks") 
        print(surface.genus())
        print(part_index, i, j)
        
        for new_part_index, new_part in enumerate(surface.info):
            if part_index == new_part_index: continue
            
            new_surface.append(list(map(lambda x: (surface.min - 1) if (x==b1 or x==b2) else x, new_part)))
            
        main1 = [surface.info[part_index][i+1:j] + [surface.min - 1]]
        main2 = [surface.info[part_index][j+1:] + surface.info[part_index][:i] + [surface.min - 1]]
        
        final = new_surface + main1 + main2

        generator.shorten_buser_cut(final)    
        l = generator.count_length(final, surface.min - 1)
        
        print(Orientable_Bounded_Combinatorial(final, surface.max, surface.min - 1).genus())
                    
        return [Orientable_Bounded_Combinatorial(final, surface.max, surface.min - 1)], l
    
    def length_of_path(self, graph, i, j):
        
        predecessor = dict()
        
        q = deque([(i, 0)])
        vis = set([i])
        while q:
            x, l = q.popleft()
            for k in graph[x]:
                if not k in vis:
                    
                    q.append((k, l+1))
                    vis.add(k)
                    predecessor[k] = x
                    
                    if k == j:
                        path = []
                        while k != i:
                            path.append(k)
                            k = predecessor[k]

                        path.append(k)
                        path.reverse()
                        return l + 1, path
        
        return float('inf')
    
    # return list of form length, boundary component 1, part index 1, boundary component 2, part index 2
    def find_shortest_buser(self, surface):
        val_to_index = generator.make_D(surface.info)

        graph = [set() for _ in range(len(surface.info))]
        values = [set() for _ in range(len(surface.info))]
        
        length_of_bc = {}

        # making the following dicts that map bc to index in graph
        
        for part_index, part in enumerate(surface.info):
            for part_index_2, val in enumerate(part):
                if val < 0:
                    values[part_index].add(val)
                    
                    if val not in length_of_bc: length_of_bc[val] = 0
                    length_of_bc[val] += 1
                
                # This is still O(n^2) because val_to_index[val] has at most 2 values
                for other in val_to_index[val]:
                    if other[0] != part_index:
                        graph[part_index].add(other[0])
        
        # of form length, boundary component 1, part index 1, boundary component 2, part index 2
        min_length = [float('inf')]
        min_path = []
                        
        for i in range(len(surface.info)):
            for j in range(len(surface.info)):
                bcs = list(map(lambda x: x, values[i].union(values[j])))
                if len(bcs) < 2: continue
                bc_l = [(length_of_bc[bc], bc) for bc in bcs]
                bc_l.sort()
                
                if bc_l[0][0] + bc_l[1][0] >= min_length[0]:
                    continue
                
                l_0 = bc_l[0][0] + bc_l[1][0]
                
                if bc_l[0][1] in values[i] and bc_l[1][1] in values[i]:
                    min_length = [l_0, bc_l[0][1], i, bc_l[1][1], i]
                    min_path = [i]
                    continue
                    
                if bc_l[0][1] in values[j] and bc_l[1][1] in values[j]:
                    min_length = [l_0, bc_l[0][1], j, bc_l[1][1], j]
                    min_path = [j]
                    continue
                
                l, path = self.length_of_path(graph, i, j)
                l += l_0
                if l >= min_length[0]:
                    continue
                
                min_path = path
                
                if bc_l[0][1] in values[i]:
                    min_length = [l, bc_l[0][1], i, bc_l[1][1], j]
                else:
                    min_length = [l, bc_l[1][1], i, bc_l[0][1], j]
                    
        return min_length, min_path
                    
    # find shortest buser cut
    def buser_cut_shortest(self, surface):
        
        # list of form length, boundary component 1, part index 1, boundary component 2, part index 2
        min_length, min_path = self.find_shortest_buser(surface)
        print(min_length)
        
        a = min_length[1]
        b = min_length[3]
        
        
        if min_length[2] == min_length[4]:
            
            part_index = min_length[2]
            
            i = surface.info[part_index].index(a)
            j = surface.info[part_index].index(b)
            
            if j < i:
                i, j = j, i
                a, b = b, a
            
            new_surface = []
            
            for new_part_index, new_part in enumerate(surface.info):
                if part_index == new_part_index: continue
                
                new_surface.append(list(map(lambda x: (surface.min - 1) if (x==a or x==b) else x, new_part)))
                
            main1 = [surface.info[part_index][i+1:j] + [surface.min - 1]]
            main2 = [surface.info[part_index][j+1:] + surface.info[part_index][:i] + [surface.min - 1]]
            
            final = new_surface + main1 + main2
            
            # generator.shorten_buser_cut(final)    
            
            # l = map(lambda x: (1) if (surface.min - 1 in x) else 0, final)  
            l = generator.count_length(final, surface.min - 1)
                      
            return [Orientable_Bounded_Combinatorial(final, surface.max, surface.min - 1)], l
        
        print("here")
            
        # i = surface.info[min_length[2]].index(a)
        # j = surface.info[min_length[4]].index(b)
        
        # if there aren't unique cuts in the same region
                
        # make a dict to put all edge values
        val_to_index = generator.make_D(surface.info)
        
        path_as_set = set(min_path)
        
        new_surface = []
        
        # when splitting edges into two, the order is important. keeping track of which edges we split means that when we see it a second time, we can flip position
        seen_pairs = set()
        
        for new_part_index in min_path[1:-1]:
            
            new_part = surface.info[new_part_index]
            
            order = min_path.index(new_part_index)
                
            if order != 1 and order != len(min_path) - 2:
                
                # middle path
                
                for part_index, val in enumerate(new_part):
                    
                    if val < 0: continue
                    
                    for x in val_to_index[val]:
                        # if x[0] == min_path[order - 1]: i = part_index
                        if x[0] == min_path[order + 1]: j = part_index
                        
                    if val in seen_pairs:
                        i = part_index
                    
                i, j = min(i, j), max(i, j)
                
                p1 = [surface.info[new_part_index][i] + surface.max] + surface.info[new_part_index][i+1:j+1] + [surface.min - 1]
                p2 = [surface.info[new_part_index][j] + surface.max] + surface.info[new_part_index][j+1:] + surface.info[new_part_index][:i+1] + [surface.min - 1]
                
                if surface.info[new_part_index][i] in seen_pairs:
                    p1[0] = surface.info[new_part_index][i]
                    p2[-2] = surface.info[new_part_index][i] + surface.max
                
                if surface.info[new_part_index][j] in seen_pairs:
                    p2[0] = surface.info[new_part_index][j]
                    p1[-2] = surface.info[new_part_index][j] + surface.max
                
                seen_pairs.add(surface.info[new_part_index][i])
                seen_pairs.add(surface.info[new_part_index][j])
                
                new_surface.append(p1)
                new_surface.append(p2)
                
                print(new_part)
                print(p1, p2)
                
                continue
                
            # one of two endpoints
            
            i = None
            for part_index, val in enumerate(new_part):
                
                if val == a or val == b and i is None:
                    i = part_index
                    continue
                
                for x in val_to_index[val]:
                    if x[0] == min_path[order + 1]:
                        j = part_index
                        
                if val in seen_pairs:
                    j = part_index
                        
            if i < j:
                p1 = surface.info[new_part_index][i+1:j+1] + [surface.min - 1]
                p2 = [surface.info[new_part_index][j] + surface.max] + surface.info[new_part_index][j+1:] + surface.info[new_part_index][:i] + [surface.min - 1]
                        
            else:
                p1 = surface.info[new_part_index][i+1 : ] + surface.info[new_part_index][:j+1] + [surface.min - 1]
                p2 = [surface.info[new_part_index][j] + surface.max] + surface.info[new_part_index][j+1:i] + [surface.min - 1]
            
            if surface.info[new_part_index][j] in seen_pairs:
                p2[0] = surface.info[new_part_index][j]
                p1[-2] = surface.info[new_part_index][j] + surface.max
                
            seen_pairs.add(surface.info[new_part_index][j])
                
            new_surface.append(list(map(lambda x: (surface.min - 1) if (x==a or x==b) else x, p1)))
            new_surface.append(list(map(lambda x: (surface.min - 1) if (x==a or x==b) else x, p2)))
            
        
        for new_part_index, new_part in enumerate(surface.info):
            if new_part_index in path_as_set:
                
                
                continue
                                
            new_surface.append(list(map(lambda x: (surface.min - 1) if (x==a or x==b) else x, new_part)))
        

        generator.shorten_buser_cut(new_surface)    

        # l = map(lambda x: (1) if (surface.min - 1 in x) else 0, new_surface)
        l = generator.count_length(new_surface, surface.min - 1)
            
        return [Orientable_Bounded_Combinatorial(new_surface, surface.max * 2, surface.min - 1)], l
      
    
    def cut_from_graph_and_endpoints(self, surface, graph, start, end):
        
        path = generator.one_cut_shortest_path(graph, start[0], end[0])
        
        
        edge_start_end = surface.info[start[0]][start[1]]
        
        # if self.i == 42:
        #     print("the start {}, end {}, value {}, and path {}".format(start, end, edge_start_end, path))
        #     print(graph)

        
        new_surface = []
        path_as_set = set(path)
        
        for path_index, part_index in enumerate(path):

            for connect in graph[part_index]:
                if connect[0] == path[path_index - 1]: 
                    m = connect[1]
                if connect[0] == path[(path_index + 1) % len(path)]: 
                    n = connect[1]
                    
                    
            if path_index == 0:
                m = edge_start_end
            if path_index + 1 == len(path):
                n = edge_start_end
                    
            for part_index_2, val in enumerate(surface.info[part_index]):
                if val == m:
                    mi = part_index_2
                if val == n:
                    ni = part_index_2
                    
            if mi < ni:
                p1 = surface.info[part_index][mi:ni+1]  + [surface.min - 1]
                p2 = [surface.info[part_index][ni] + surface.max] + surface.info[part_index][ni+1:] + surface.info[part_index][:mi] + [surface.info[part_index][mi] + surface.max] + [surface.min - 2]
                
            else:
                p1 = surface.info[part_index][mi:] + surface.info[part_index][:ni+1] + [surface.min - 1]
                p2 = [surface.info[part_index][ni] + surface.max] + surface.info[part_index][ni+1:mi] + [surface.info[part_index][mi] + surface.max] + [surface.min - 2]
                    
            new_surface.append(p1)
            new_surface.append(p2)   
                    
        for part_index, part in enumerate(surface.info):

            if part_index not in path_as_set:
                new_surface.append(part)
        
        return generator.split_potentially_different(new_surface, surface.max * 2, surface.min -2), generator.count_length(new_surface, surface.min - 1)
    
  
    def polygon_cut(self, surface):
        
        # this function assumes redundancies and no length 1 cuts are available
        
        val_to_index = generator.make_D(surface.info)
        
        graph = [set() for _ in range(len(surface.info))] 
        
        starting_cp = max((len(l), i) for i, l in enumerate(surface.info))[1]
        
        # modification of BFS algorithm
        q = deque([(starting_cp, None)]) #second index is the value of the edge that connectes that cp to its parent cp
        vis = set([starting_cp]) # all visited cps
        vis_edge = set()
        while q:
            [x, prev] = q.popleft()
            
            for val_index, val in enumerate(surface.info[x]):
                
                # ensure we dont look at edge that connects to parent cp
                if val == prev: continue
                if val < 0: continue
                
                # find that other edge of value val is at info[a][b]
                for other in val_to_index[val]:
                    if other[0] != x or other[1] != val_index:
                        [a, b] = other

                if a == x:
                    continue
                
                if a in vis:
                    surfaces, l = self.cut_from_graph_and_endpoints(surface, graph, [x, val_index], [a, b])
                    
                    # the two if statements test contractibility
                    if len(surfaces) == 2:
                        if surfaces[0].genus() == 0 or surfaces[1].genus() == 0:
                            continue

                    # not contractible if here
    
                    return surfaces, l
                
                # here a is not in visited, so we add the other connected part to the graph
                
                graph[x].add((a, val))
                graph[a].add((x, val))
                vis.add(a)
                vis_edge.add(val)
                
                if len(surface.info[a]) == 3 and min(surface.info[a]) < 0:
                    q.appendleft((a, val))
                else:
                    q.append((a, val))
               
           
    def remove_genus_decomposition(self, surface):
        
        self.i += 1
        print(self.i)
        
        # start_info = copy.deepcopy(surface.info)
        if surface.genus() == 0:
            
            return 0, 0, []
            
            
        
        connected_parts = len(surface.info)
        big_connected_parts = sum(int(len(cp)!=3) for cp in surface.info)
        
        surface.remove_redundant_information()
        # surface.remove_bc()
        
        c = generator.general_simple_cut(surface)
        if c:
            l = 1
            all_cuts = [['0', 1, connected_parts, big_connected_parts]]
            max_length = l
            total_length = l
            print(all_cuts)
            for s in c:
                ml, tl, na = self.remove_genus_decomposition(s)
                all_cuts += na
                max_length = max(ml, max_length)
                total_length += tl
            return max_length, total_length, all_cuts

        for a in range(len(surface.info)):
            if len(surface.info[a]) == 4 and sum(i >= 0 for i in surface.info[a]) == 2:
                if sorted(surface.info[a])[1] == min(surface.info[a]):
                    raise Exception
                    

        for a in range(len(surface.info)):
            if len(surface.info[a]) == 4 and sum(i >= 0 for i in surface.info[a]) == 2:
                # print(a)
                c, l = self.buser_cut_modified(surface, a)
                all_cuts = [['2', l, connected_parts, big_connected_parts]]

        if not c:
            c, l = self.polygon_cut(surface)
            all_cuts = [['1', l, connected_parts, big_connected_parts]]

        max_length = l
        total_length = l
        
        print(all_cuts)

        for s in c:
            ml, tl, na = self.remove_genus_decomposition(s)
            all_cuts += na
            max_length = max(ml, max_length)
            total_length += tl
        
        return max_length, total_length, all_cuts
    
           
    # return index of [x, b, y, b] is such a cp exists
    # false otherwise
    def has_cp4_same(self, surface):
        for a in range(len(surface.info)):
            if len(surface.info[a]) == 4 and sum(i >= 0 for i in surface.info[a]) == 2:
                if sorted(surface.info[a])[1] == min(surface.info[a]):
                    return a
        
        return False
    
    # return index of [x, b1, y, b2] is such a cp exists
    # false otherwise
    def has_cp4(self, surface):
        for a in range(len(surface.info)):
            if len(surface.info[a]) == 4 and sum(i >= 0 for i in surface.info[a]) == 2:
                return a
        
        return False
    

    def full_decomposition(self, surface):
        
        # testing only: print(surface)
        
        if generator.is_pant(surface):
            return 0, 0, []
            
        connected_parts = len(surface.info)
        big_connected_parts = sum(int(len(cp)>3) for cp in surface.info)
        
        if surface.genus() == 0:
            
            if self.has_cp4_same(surface):
                c, l = self.buser_cut_four_same_bc(surface, self.has_cp4_same(surface))
                all_cuts = [['2', l, connected_parts, big_connected_parts]]
                
            elif self.has_cp4(surface):
                c, l = self.buser_cut_modified(surface, self.has_cp4(surface))
                all_cuts = [['2', l, connected_parts, big_connected_parts]]
            
            else:
                try:
                    c, l = generator.shorten_buser_cut(surface)
                    [c[i].genus() for i in range(len(c))]
                except:
                    c, l = generator.buser_cut(surface)
                all_cuts = [['3', l, connected_parts, big_connected_parts]]
        
        else:
        
            c = generator.general_simple_cut(surface)
            if c:
                l = 1
                all_cuts = [['0', 1, connected_parts, big_connected_parts]]
              
            elif self.has_cp4_same(surface):
                c, l = self.buser_cut_four_same_bc(surface, self.has_cp4_same(surface))
                all_cuts = [['2', l, connected_parts, big_connected_parts]]
                
            elif self.has_cp4(surface):
                c, l = self.buser_cut_modified(surface, self.has_cp4(surface))
                all_cuts = [['2', l, connected_parts, big_connected_parts]]

            else:
                c, l = self.polygon_cut(surface)
                all_cuts = [['1', l, connected_parts, big_connected_parts]]

        max_length = l
        total_length = l
        
        print(all_cuts)

        for s in c:
            ml, tl, na = self.full_decomposition(s)
            all_cuts += na
            max_length = max(ml, max_length)
            total_length += tl
        
        return max_length, total_length, all_cuts