import random
import surfaces

class Random_Combinatorial():
    def __init__(self) -> None:
        pass
    
    # remove random element from a list
    def pop_random(self, lst):
        idx = random.randrange(0, len(lst))
        return lst.pop(idx)
    
    # sides is an integer for the number of sides
    def generate_random_info(self, sides):
        lst = [i for i in range(1, sides // 2 + 1)] + [i for i in range(1, sides // 2 + 1)]

        info = [None for _ in range(sides)]
        for count in range(sides):
            info[count] =  self.pop_random(lst)
            
        return [info], max(info)
    
    # sides is an integer for the number of sides
    def generate_simple_info(self, genus):
        sides = genus * 4
        info = []
        for i in range(sides):
            if i % 4 == 0 or i % 4 == 2:
                info.append(i // 4 * 2 + 1)
            if i % 4 == 1 or i % 4 == 3:
                info.append(i // 4 * 2 + 2)
            
        return [info], max(info)
    
    # sides and orientation are just as in generate_random_adj
    def generate_random_surface(self, sides):
        i, m = self.generate_random_info(sides)
        return surfaces.Orientable_Bounded_Combinatorial(i, m, 0)
    
    # sides and orientation are just as in generate_random_adj
    def generate_simple_surface(self, genus):
        i, m = self.generate_simple_info(genus)
        return surfaces.Orientable_Bounded_Combinatorial(i, m, 0)