from  surfaces import *
from random_combinatorial import *
from greedy_decomposition import *
import numpy as np
import random



generator = Random_Combinatorial()
g = Pants_Decomposition()
greedy = Greedy_Decomposition()


def gen(func, mi, ma):
    s = func(random.randint(mi / 2, ma / 2) * 2)
    while s.genus() < 2:
        s = func(random.randint(mi / 2, ma / 2) * 2)
    return s


def output(func, mi, ma):
    s = gen(func, mi, ma)

    result = greedy.full_decomposition(s)
    
    print(result)
   

with open('specific_graphs/genus_algorithm/genus_vs_length/genus_vs_length_data.txt', 'a') as t:
    
    for z in range(1, 1000):
        s = gen(generator.generate_random_surface, 450, 500)
        print(f"WE ARE NOW DONE WITH {z} TRIALS")
        try:
            result = greedy.full_decomposition(s)
            t.write(f"\n{s.genus()} {result[0]} {result[1]}")
        except:
            pass
