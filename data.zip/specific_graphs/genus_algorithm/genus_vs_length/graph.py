import matplotlib.pyplot as plt
import pandas as pd
import numpy as np


# data = open("data.txt", "r").read().split("\n\n")[2].split("\n")[1:]
data = open("specific_graphs/genus_algorithm/genus_vs_length/genus_vs_length_data.txt", "r").read().split("\n")
data.sort(key=lambda x: list(map(int, x.split()))[0])
data = data[:-86]

print(max([list(map(int, x.split()))[0] for x in data]))
    
df = pd.DataFrame({'g': [list(map(int, x.split()))[0] for x in data], 'l': [list(map(int, x.split()))[1] for x in data], 'tl': [list(map(int, x.split()))[2] for x in data]})

plt.grid()

def total_length_reg(x):
    return 4*x - 4

x = np.linspace(0, 100, 100)
# plt.plot(x, total_length_reg(x), color='red')

model = np.poly1d(np.polyfit((df['g']), (df['l']), 1))
polyline = np.linspace(0, 116, 50)

# plt.scatter((df['g']), (df['l']), alpha=0.2, color='blue', s=40)
# plt.scatter((df['g']), (2*np.log2(df['real'])+1), alpha=0.5, color='green', s=40)

# print(model)

    
df.groupby("g")['l'].mean().plot()
# dl.groupby("g")['l'].mean().plot()
# df.groupby("g")['tl'].mean().plot()

# plt.plot(polyline, model(polyline), color = 'black', alpha=1)


plt.xlabel("Genus")
plt.ylabel("Average Sum Length of Pants Decomposition")
plt.title("Average Pants Decomposition Sum Length vs. Genus")

plt.show()

