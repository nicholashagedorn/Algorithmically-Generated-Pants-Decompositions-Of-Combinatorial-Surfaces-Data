import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

data = open("specific_graphs/new_algorithm/i_vs_length_of_one_surface/data.txt", "r").read().split("\n")[1:]
data = open("specific_graphs/new_algorithm/i_vs_length_of_one_surface/genus_vs_length_data.txt", "r").read().split("\n")

# data = [f"{i+1} {original[i]}" for i in range(len(original))]

print([list(map(int, x.split()))[0] for x in data])

df = pd.DataFrame({'i': [list(map(int, x.split()))[0] for x in data], 'l': [list(map(int, x.split()))[1] for x in data]})
# df = pd.DataFrame({'i': [list(map(int, x.split()))[0] for x in data], 'l': sorted([list(map(int, x.split()))[1] for x in data])})

plt.grid()

def total_length_reg(x):
    # return 0.008952*x**2 - 0.03139*x - 0.375
    return 4*x/3

# x = np.linspace(0, 300, 100)
# plt.plot(x, total_length_reg(x), color='red')

model = np.poly1d(np.polyfit((df['i']), (df['l']), 2))
polyline = np.linspace(0, 500, 50)

# plt.plot(x, total_length_reg(x), color='red')


# plt.scatter((df['i']), (df['l']), alpha=0.4, color='blue', s=40)
# plt.scatter((df['g']), (2*np.log2(df['real'])+1), alpha=0.5, color='green', s=40)

print(model)

    
df.groupby("i")['l'].mean().plot()
# df.groupby("g")['tl'].mean().plot()

# plt.plot(polyline, model(polyline), color = 'black', alpha=1)


plt.xlabel("Cut $n$")
plt.ylabel("Length of $n$th cut")

plt.title("Pants Decomposition of a Genus 50 Surface")

plt.show()

