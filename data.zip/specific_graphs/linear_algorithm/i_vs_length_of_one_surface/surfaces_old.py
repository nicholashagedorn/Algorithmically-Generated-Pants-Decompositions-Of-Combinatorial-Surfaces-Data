from collections import deque
from rich import print
    

class Orientable_Bounded_Combinatorial:
    def __init__(self, info, maximum, minimum) -> None:
        
        self.info = info
        
        # mobius strip
        # info = [ [0, -1, 0, -1] ]
        
        # highest numbered part + minimum boundary component
        self.max = maximum
        self.min = minimum
        
        
    # assuming no two consecutive boundary components
    # O(n) time algorithm
    def vertices(self):
        # vertex 2D array where i and j are the same vertex if self.v[a][b] = self.v[c][d]
        self.v = [[-1 for _ in range(len(self.info[i]))] for i in range(len(self.info))] 
        
        val_to_index = dict()
        
        for part_index, part in enumerate(self.info):
            for part_index_2, val in enumerate(part):
                if val not in val_to_index: val_to_index[val] = []
                
                val_to_index[val].append([part_index, part_index_2])
        
        # self.v initially contains no information. we fill in the information in the following BFS algorithm
        counter = 0
        for i in range(len(self.info)):
            for j in range(len(self.info[i])):
                
                if self.v[i][j] != -1:
                    continue
                
                # we set up a queue to add vertices
                # this is part of a BFS algorithm
                self.v[i][j] = counter
                q = deque()
                q.append([i, j])
                while q:
                    [a, b] = q.popleft()
                    
                    # if we visualize the vertices a vertex is equivalent to as a graph (two vertices are equal if they are part of the same connected component), ns contains the two values a can be neighbors with
                    
                    ns = []
                    
                    # the if statements check whether the edges next to the vertex are paired edges
                    if self.info[a][b-1] >= 0:
                        # search through every edge paired with edge b-1 in connected part a
                        for x in val_to_index[self.info[a][b-1]]:
                            # this if statement checks that the edge we are looking at isnt edge b-1 in connected part a (we want to find different edges)
                            if (x[0] - a) % len(self.info) != 0 or (x[1] - (b-1)) % len(self.info[a]) != 0:
                                # add edges to ns, the edges that we are going to look at next in the BFS algorithm
                                ns += [[x[0] % len(self.info), x[1]] ]
                    
                    if self.info[a][b] >= 0:
                        # search through every edge paired with edge b in connected part a
                        for x in val_to_index[self.info[a][b]]:
                            # this if statement checks that the edge we are looking at isnt edge b in connected part a (we want to find different edges)
                            if (x[0] - a) % len(self.info) != 0 or (x[1] - (b)) % len(self.info[a]) != 0:
                                ns += [[x[0] % len(self.info), x[1]+1]]
                    
                    ns = [[n[0], n[1] % len(self.info[n[0]])] for n in ns]

                    # add edges in ns to queue, meaning we will search through them soon
                    for n in ns:
                        if self.v[n[0]][n[1]] == -1:
                            q.append(n)
                        self.v[n[0]][n[1]] = counter
                        
                counter += 1
        
        # this finds the number of unique vertices     
        v_set = set()
        for sub_l in self.v:
            v_set.update(sub_l)
        v = len(v_set)
            
            
        return v
    
    # Algorithm is O(1) by itself but O(n) because of call of vertex function
    def genus(self):
        # 2 - 2g - unique b.c. = V - total b.c. + F
        # 2g = 2 - unique b.c. + total b.c. - V + F
        
        bc = set()
        total_bc = 0
        e = set()
        
        # finds total_bc, the total number of boundary component edges in the surface
        # finds bc, which is a set of all types of boundary components. len(bc) is the number of unique boundary components
        for part_index, part in enumerate(self.info):
            for part_index_2, val in enumerate(part):
                if val < 0:
                    total_bc += 1
                    bc.add(val)
                else:
                    e.add(val)
                       
        f = len(self.info) # the number of faces
        v = self.vertices() # the number of unique vertices
        unique_bc = len(bc)
        
        g = (2 - unique_bc + total_bc - v - f + len(e)) / 2 # the genus
        
        if not g.is_integer(): 
            raise TimeoutError("Surface has non-integer genus")
        
        return int(g)
    
    # Find the number of unique boundary components in a surface
    def unique_bc(self):
        
        bc = set()
        
        # put all boundary components in a set and find the length of that set
        for part_index, part in enumerate(self.info):
            for part_index_2, val in enumerate(part):
                if val < 0:
                    bc.add(val)
                    
        return len(bc)
    
    # Find a set of all boundary components in a surface
    def actual_bc(self):
        
        # Same implementation as unique_bc, aside from it returns bc instead of len(bc)
        
        bc = set()
        
        for part_index, part in enumerate(self.info):
            for part_index_2, val in enumerate(part):
                if val < 0:
                    bc.add(val)
                    
        return bc
        
    
        
class Pants_Decomposition():
    def __init__(self) -> None:
        pass
    
    # determine if two connected parts are in the same surface
    # runs in O(n) time
    def are_unique(self, p1, p2):
        
        # p1_set is a set of all values in p1. the same applies to p2_set
        # by putting all values in sets, we can use the isdisjoint function to efficiently find whether there is any overlap
        
        p1_set = set()
        for sub_l in p1:
            p1_set.update(sub_l)
        
        p2_set = set()
        for sub_l in p2:
            p2_set.update(sub_l)
        
        return p1_set.isdisjoint(p2_set)
    
    # make a dict to put all edge values
    # O(n) time
    def make_D(self, info):
        val_to_index = dict()
        
        for part_index, part in enumerate(info):
            for part_index_2, val in enumerate(part):
                if val not in val_to_index: val_to_index[val] = []
                
                val_to_index[val].append([part_index, part_index_2])
                
        return val_to_index
    
    # find the indices of a cut of length 1 in a surface if it exists. return false if none exists
    def find_general_simple_cut(self, surface):
        
        # search through every connected part to see if a simple cut exists
        for part_index, part in enumerate(surface.info):
            
            # j and i will be two pointers that will loop through the entire connected part
            j, i = 0, 1
        
            # we continuously move j and i until we find a cut or until we know none exists
            while j < len(part) - 2:
               
               # conditions that mean a cut between j and i dont form a connected part 
                if i >= len(part):
                    j += 1
                    i = j + 1
                    continue
                
                # if they are boundary components
                if part[j] < 0:
                    j += 1
                    i = j + 1
                    continue
                
                # if j and i arent the same edge pairing
                if part[i] != part[j]:
                    i += 1
                    continue
            
                # if j and i are right next to each other
                if j + 1 == i:
                    j += 2
                    i = j + 1
                    continue
                
                # if all edges between j and i pair together such that a cut between j and i is contractable
                works = False
                for k in range(1,  int((i-j+2) / 2) ):
                    if part[i-k] != part[j+k]:
                        works = True
                        break
                    
                    if i - k == j + k and part[j + k] >= 0:
                        works = True
                        break
                if not works:
                    j = i + 1
                    i = j + 1
                    continue
                
                works = False
                for k in range(1,  int((len(part) - (i - j) + 2) / 2) ):
                    if part[j-k] != part[(i+k) % len(part)]:
                        works = True
                        break
                    
                    if (j - k) % len(part) == (i + k) % len(part) and part[j - k] >= 0:
                        works = True
                        break
                    
                if not works:
                    j += 1
                    i = j + 1
                    continue
                
                
                
                # if we reach here, a cut between j and i form a connected part 
                if self.is_general_simple_cut_mid_result_pant(surface, [part_index, j, i]):
                

                    return [part_index, j, i]
                
                else:
                    j += 1
                    i = j + 1
            
        return False
    
    def is_general_simple_cut_mid_result_pant(self, surface, cut_values):
        
        [part_index, j, i] = cut_values
        part = surface.info[part_index]
                
        p1 = part[j:i+1]
        p1.append(surface.min - 1)
        
        p2 = part[i:] + part[:j+1]
        p2[0] = surface.max + 1
        p2[-1] = surface.max + 1
        p2.append(surface.min - 2)
        
        # if p1 and p2 have overlap, than the entire surface is connected and we can return it as one surface
        
        if not self.are_unique([p1], [p2]):

            return [Orientable_Bounded_Combinatorial(surface.info[ : part_index] + [p1, p2] + surface.info[part_index + 1 : ], surface.max + 1, surface.min - 2)]
        
        # if p1 and p2 are disjoint, that means we dont know if we split the surface into two or not. so, we run a BFS algorithm just like how we found the vertices of the cuts to see what parts are in each of the potentially multiple surfaces
        
        info = [p1, p2] + surface.info[ : part_index] + surface.info[part_index + 1 : ]
        
        
        # creating dictionaries that make it quick to make the graph
        val_to_index = dict()
        
        for new_part_index, part in enumerate(info):
            for val in part:
                if val not in val_to_index: val_to_index[val] = set()
                
                val_to_index[val].add(new_part_index)
        
        # creating the graph that connects different connected parts if they have an edge pairing connecting them
        graph = [set() for _ in range(len(info))] 
        
        for new_part_index, part in enumerate(info):
            for val in part:
                if val < 0:
                    continue
                
                # This is still O(n^2) because val_to_index[val] has at most 2 values
                for other in val_to_index[val]:
                    if other != new_part_index:
                        graph[new_part_index].add(other)
             
        # running BFS on the graph
               
        q = deque([0])
        vis = set([0])
        while q:
            x = q.popleft()
            for k in graph[x]:
                if not k in vis:
                    q.append(k)
                    vis.add(k)
        
        
        # if 1 is in the visited nodes, that means there is some path between p1 (at index 0) and p2 (at index 1). that means the result is still one connected surface
        if 1 in vis:
            return Orientable_Bounded_Combinatorial(info, surface.max + 1, surface.min - 2).genus() * 3 + Orientable_Bounded_Combinatorial(info, surface.max + 1, surface.min - 2).unique_bc() >= 4
        
        # if we are here, the cut divided the original surface into two surfaces. i1 and i2 are these two new surfaces
        # i1 is all the vertices connected to p1
        i1 = [info[a] for a in vis]
        
        # we now run BFS from p2. then vis is all parts connected to p2. we add these to i2
        q = deque([1])
        vis = set([1])
        while q:
            x = q.popleft()
            for k in graph[x]:
                if not k in vis:
                    q.append(k)
                    vis.add(k)
                    
        i2 = [info[a] for a in vis]
        
        # return the two new surfaces
        return Orientable_Bounded_Combinatorial(i1, surface.max + 1, surface.min - 2).genus() * 2 + Orientable_Bounded_Combinatorial(i1, surface.max + 1, surface.min - 2).unique_bc() >= 3 and Orientable_Bounded_Combinatorial(i2, surface.max + 1, surface.min - 2).genus() * 2 + Orientable_Bounded_Combinatorial(i2, surface.max + 1, surface.min - 2).unique_bc() >= 3
        
    def general_simple_cut(self, surface):
        
        # get the indices for the cut
        cut_values = self.find_general_simple_cut(surface)
        if not cut_values:
            return False
        
        # create p1 and p2, which are the two new connected parts made after the cut
        
        [part_index, j, i] = cut_values
        part = surface.info[part_index]
                
        p1 = part[j:i+1]
        p1.append(surface.min - 1)
        
        p2 = part[i:] + part[:j+1]
        p2[0] = surface.max + 1
        p2[-1] = surface.max + 1
        p2.append(surface.min - 2)
        
        # if p1 and p2 have overlap, than the entire surface is connected and we can return it as one surface
        
        if not self.are_unique([p1], [p2]):

            return [Orientable_Bounded_Combinatorial(surface.info[ : part_index] + [p1, p2] + surface.info[part_index + 1 : ], surface.max + 1, surface.min - 2)]
        
        # if p1 and p2 are disjoint, that means we dont know if we split the surface into two or not. so, we run a BFS algorithm just like how we found the vertices of the cuts to see what parts are in each of the potentially multiple surfaces
        
        info = [p1, p2] + surface.info[ : part_index] + surface.info[part_index + 1 : ]
        
        
        # creating dictionaries that make it quick to make the graph
        val_to_index = dict()
        
        for new_part_index, part in enumerate(info):
            for val in part:
                if val not in val_to_index: val_to_index[val] = set()
                
                val_to_index[val].add(new_part_index)
        
        # creating the graph that connects different connected parts if they have an edge pairing connecting them
        graph = [set() for _ in range(len(info))] 
        
        for new_part_index, part in enumerate(info):
            for val in part:
                if val < 0:
                    continue
                
                # This is still O(n^2) because val_to_index[val] has at most 2 values
                for other in val_to_index[val]:
                    if other != new_part_index:
                        graph[new_part_index].add(other)
             
        # running BFS on the graph
               
        q = deque([0])
        vis = set([0])
        while q:
            x = q.popleft()
            for k in graph[x]:
                if not k in vis:
                    q.append(k)
                    vis.add(k)
        
        
        # if 1 is in the visited nodes, that means there is some path between p1 (at index 0) and p2 (at index 1). that means the result is still one connected surface
        if 1 in vis:
            return [Orientable_Bounded_Combinatorial(info, surface.max + 1, surface.min - 2)]
        
        # if we are here, the cut divided the original surface into two surfaces. i1 and i2 are these two new surfaces
        # i1 is all the vertices connected to p1
        i1 = [info[a] for a in vis]
        
        # we now run BFS from p2. then vis is all parts connected to p2. we add these to i2
        q = deque([1])
        vis = set([1])
        while q:
            x = q.popleft()
            for k in graph[x]:
                if not k in vis:
                    q.append(k)
                    vis.add(k)
                    
        i2 = [info[a] for a in vis]
        
        # return the two new surfaces
        return [
            Orientable_Bounded_Combinatorial(i1, surface.max + 1, surface.min - 2),
            Orientable_Bounded_Combinatorial(i2, surface.max + 1, surface.min - 2)
            ]
                    
    def split_potentially_different(self, info, new_max, new_min):
        
        # creating dictionaries that make it quick to make the graph
        val_to_index = dict()
        
        for new_part_index, part in enumerate(info):
            for val in part:
                if val not in val_to_index: val_to_index[val] = set()
                
                val_to_index[val].add(new_part_index)
        
        # creating the graph that connects different connected parts if they have an edge pairing connecting them
        graph = [set() for _ in range(len(info))] 
        
        for new_part_index, part in enumerate(info):
            for val in part:
                if val < 0:
                    continue
                
                # This is still O(n^2) because val_to_index[val] has at most 2 values
                for other in val_to_index[val]:
                    if other != new_part_index:
                        graph[new_part_index].add(other)
             
        # running BFS on the graph
               
        q = deque([0])
        vis = set([0])
        while q:
            x = q.popleft()
            for k in graph[x]:
                if not k in vis:
                    q.append(k)
                    vis.add(k)
        
        
        # if 1 is in the visited nodes, that means there is some path between p1 (at index 0) and p2 (at index 1). that means the result is still one connected surface
        if 1 in vis:
            return [Orientable_Bounded_Combinatorial(info, new_max, new_min)]
        
        # if we are here, the cut divided the original surface into two surfaces. i1 and i2 are these two new surfaces
        # i1 is all the vertices connected to p1
        i1 = [info[a] for a in vis]
        
        # we now run BFS from p2. then vis is all parts connected to p2. we add these to i2
        q = deque([1])
        vis = set([1])
        while q:
            x = q.popleft()
            for k in graph[x]:
                if not k in vis:
                    q.append(k)
                    vis.add(k)
                    
        i2 = [info[a] for a in vis]
        
        # return the two new surfaces
        return [
            Orientable_Bounded_Combinatorial(i1, new_max, new_min),
            Orientable_Bounded_Combinatorial(i2, new_max, new_min)
            ]

    # return an array of either one or two surfaces
    # input is a surface with 1 boundary component and thus genus≥1
    def one_boundary_cut(self, surface):
        
        val_to_index = dict()
                
        graph = [set() for _ in range(len(surface.info))]
        poly_info = []
        unvisited = set([i for i in range(len(surface.info))])
        all_edge_numbers = set()
        
        for part_index, part in enumerate(surface.info):
            for part_index_2, val in enumerate(part):
                if val not in val_to_index: val_to_index[val] = []
                
                val_to_index[val].append([part_index, part_index_2])
                if val < 0:
                    boundary = val
                else:
                    all_edge_numbers.add(val)
                
        
        # add all connected parts that contain the boundary component
        
        a, b = map(int, val_to_index[boundary][0])
        
        
        while True:
            
            if a not in unvisited:
                break
            
            unvisited.remove(a)
            
            new = []
            for i, val in enumerate(surface.info[a]):
                if (i+1) % len(surface.info[a])!=b and (i-1) % len(surface.info[a])!=b  and (i) % len(surface.info[a])!=b:
                    new.append(val)
            
            poly_info += new
            
            for index in val_to_index[surface.info[a][(b-1)]]:
                if index[0] == a: continue
                
                olda = a
                a, b = map(int, index)
                b = (b-1) % len(surface.info[a])
                break
            
            v = surface.info[a][(b+1) % len(surface.info[a])]    
            graph[a].add((olda, v))
            graph[olda].add((a, v))
            
        while unvisited:
            a, b, v, olda = self.one_boundary_cut_add_to_poly(surface, unvisited, val_to_index, poly_info)
            unvisited.remove(a)
            graph[a].add((olda, v))
            graph[olda].add((a, v))
            
            pos = poly_info.index(v)
            poly_info = poly_info[:pos] + surface.info[a][b+1:] + surface.info[a][:b] + poly_info[pos+1:]

        cut_values = self.find_general_simple_cut(Orientable_Bounded_Combinatorial([poly_info], surface.max, surface.min))
        
        edge_start_end = poly_info[cut_values[1]]
        
        start = val_to_index[edge_start_end][0]
        end = val_to_index[edge_start_end][1]
        
        path = self.one_cut_shortest_path(graph, start[0], end[0])
        
        new_surface = []
        path_as_set = set(path)
        
        for path_index, part_index in enumerate(path):

            for connect in graph[part_index]:
                if connect[0] == path[path_index - 1]: 
                    m = connect[1]
                if connect[0] == path[(path_index + 1) % len(path)]: 
                    n = connect[1]
                    
                    
            if path_index == 0:
                m = edge_start_end
            if path_index + 1 == len(path):
                n = edge_start_end
                    
            for part_index_2, val in enumerate(surface.info[part_index]):
                if val == m:
                    mi = part_index_2
                if val == n:
                    ni = part_index_2
                    
            if mi < ni:
                p1 = surface.info[part_index][mi:ni+1]  + [surface.min - 1]
                p2 = [surface.info[part_index][ni] + surface.max] + surface.info[part_index][ni+1:] + surface.info[part_index][:mi] + [surface.info[part_index][mi] + surface.max] + [surface.min - 2]
                
            else:
                p1 = surface.info[part_index][mi:] + surface.info[part_index][:ni+1] + [surface.min - 1]
                p2 = [surface.info[part_index][ni] + surface.max] + surface.info[part_index][ni+1:mi] + [surface.info[part_index][mi] + surface.max] + [surface.min - 2]
                    
            new_surface.append(p1)
            new_surface.append(p2)   
                    
        for part_index, part in enumerate(surface.info):

            if part_index not in path_as_set:
                new_surface.append(part)
        
        
        return self.split_potentially_different(new_surface, surface.max * 2, surface.min -2), len(path)


             
    # Potential speed up: Use all_edge_numbers                     
    def one_boundary_cut_add_to_poly(self, surface, unvisited, val_to_index, polyinfo):
        for next_part_index in unvisited:
            for next_part_index_2, val in enumerate(surface.info[next_part_index]):
                for other in val_to_index[val]:
                    if other[0] not in unvisited and val in polyinfo:
                        return next_part_index, next_part_index_2, val, other[0]
    
    # find if there are two boundary components in the same connected part
    # return the index of the part in surface.info and two indices of the diff boundary components in that part
    # used for buser_cut function
    # runs in O(n) time
    def two_cuts_in_connected_part(self, surface):
        for part_index, part in enumerate(surface.info):
            first = None
            for i, j in enumerate(part):
                if j >= 0: continue
                
                if first is None:
                    first = [i, j]
                    continue
                
                if j == first[1]: continue
                
                return [part_index, first[0], i]
            
        return False
    
    # return an array of either one or two surfaces
    # input is a surface with ≥2 boundary components
    def buser_cut(self, surface):
        # general approach:
        # find all unique cuts
        # see if there are two UNQUE cuts in the same region
        connections = self.two_cuts_in_connected_part(surface)
        if connections:
            part_index, i, j = map(int, connections)
            a = surface.info[part_index][i]
            b = surface.info[part_index][j]
            
            new_surface = []
            
            for new_part_index, new_part in enumerate(surface.info):
                if part_index == new_part_index: continue
                
                new_surface.append(list(map(lambda x: (surface.min - 1) if (x==a or x==b) else x, new_part)))
                
            main1 = [surface.info[part_index][i+1:j] + [surface.min - 1]]
            main2 = [surface.info[part_index][j+1:] + surface.info[part_index][:i] + [surface.min - 1]]
            
            final = new_surface + main1 + main2
            
            self.shorten_buser_cut(final)    
            
            self.shorten_buser_cut(final)
            l = map(lambda x: (1) if (surface.min - 1 in x) else 0, final)            
            return [Orientable_Bounded_Combinatorial(final, surface.max, surface.min - 1)], sum(l)
        
        # if there aren't unique cuts in the same region
                
        # make a dict to put all edge values
        val_to_index = self.make_D(surface.info)

        
        graph = [set() for _ in range(len(surface.info))]
        values = [None for _ in range(len(surface.info))]
        
                            
        bc = surface.actual_bc()

        bc_to_index = dict()
        index_to_bc = dict()
        count = len(surface.info)
        while bc:
            i = bc.pop()
            index_to_bc[count] = i
            bc_to_index[i] = count
            count += 1
            graph.append(set())
        
        
        for part_index, part in enumerate(surface.info):
            for part_index_2, val in enumerate(part):
                if val < 0:
                    values[part_index] = val
                    
                    graph[bc_to_index[val]].add(part_index)
                    graph[part_index].add(bc_to_index[val])
                    continue
                
                # This is still O(n^2) because val_to_index[val] has at most 2 values
                for other in val_to_index[val]:
                    if other[0] != part_index:
                        graph[part_index].add(other[0])
                
        min_path = []
        min_distance = float('inf')
        for start in range(len(surface.info), len(graph) - 1):

            p = self.buser_cut_shortest_path(graph, start)
            if len(p) < min_distance:
                min_distance = len(p)
                min_path = p
        
        a = index_to_bc[min_path[0]]
        b = index_to_bc[min_path[-1]]
        
        path_as_set = set(min_path)
        
        new_surface = []
        
        # when splitting edges into two, the order is important. keeping track of which edges we split means that when we see it a second time, we can flip position
        seen_pairs = set()
        
        for new_part_index in min_path[1:-1]:
            
            new_part = surface.info[new_part_index]
            
            order = min_path.index(new_part_index)
                
            if order != 1 and order != len(min_path) - 2:
                
                # middle path
                
                for part_index, val in enumerate(new_part):
                    
                    if val < 0: continue
                    
                    for x in val_to_index[val]:
                        # if x[0] == min_path[order - 1]: i = part_index
                        if x[0] == min_path[order + 1]: j = part_index
                        
                    if val in seen_pairs:
                        i = part_index
                    
                i, j = min(i, j), max(i, j)
                
                p1 = [surface.info[new_part_index][i] + surface.max] + surface.info[new_part_index][i+1:j+1] + [surface.min - 1]
                p2 = [surface.info[new_part_index][j] + surface.max] + surface.info[new_part_index][j+1:] + surface.info[new_part_index][:i+1] + [surface.min - 1]
                
                if surface.info[new_part_index][i] in seen_pairs:
                    p1[0] = surface.info[new_part_index][i]
                    p2[-2] = surface.info[new_part_index][i] + surface.max
                
                if surface.info[new_part_index][j] in seen_pairs:
                    p2[0] = surface.info[new_part_index][j]
                    p1[-2] = surface.info[new_part_index][j] + surface.max
                
                seen_pairs.add(surface.info[new_part_index][i])
                seen_pairs.add(surface.info[new_part_index][j])
                
                new_surface.append(p1)
                new_surface.append(p2)
                
                continue
                
            # one of two endpoints
            
            i = None
            for part_index, val in enumerate(new_part):
                
                if val < 0 and i is None:
                    i = part_index
                    continue
                
                for x in val_to_index[val]:
                    if x[0] == min_path[order + 1]:
                        j = part_index
                        
                if val in seen_pairs:
                    j = part_index
                        
            if i < j:
                p1 = surface.info[new_part_index][i+1:j+1] + [surface.min - 1]
                p2 = [surface.info[new_part_index][j] + surface.max] + surface.info[new_part_index][j+1:] + surface.info[new_part_index][:i] + [surface.min - 1]
                        
            else:
                p1 = surface.info[new_part_index][i+1 : ] + surface.info[new_part_index][:j+1] + [surface.min - 1]
                p2 = [surface.info[new_part_index][j] + surface.max] + surface.info[new_part_index][j+1:i] + [surface.min - 1]
            
            if surface.info[new_part_index][j] in seen_pairs:
                p2[0] = surface.info[new_part_index][j]
                p1[-2] = surface.info[new_part_index][j] + surface.max
                
            seen_pairs.add(surface.info[new_part_index][j])
                
            new_surface.append(list(map(lambda x: (surface.min - 1) if (x==a or x==b) else x, p1)))
            new_surface.append(list(map(lambda x: (surface.min - 1) if (x==a or x==b) else x, p2)))
            
        
        for new_part_index, new_part in enumerate(surface.info):
            if new_part_index in path_as_set:
                
                
                continue
                                
            new_surface.append(list(map(lambda x: (surface.min - 1) if (x==a or x==b) else x, new_part)))
        

        self.shorten_buser_cut(new_surface)    

        l = map(lambda x: (1) if (surface.min - 1 in x) else 0, new_surface)
            
        return [Orientable_Bounded_Combinatorial(new_surface, surface.max * 2, surface.min - 1)], sum(l)
      
    def shorten_buser_cut_helper(self, info):
        for i, c in enumerate(info):
            if len(c) == 2: return i
        return False
        
    def shorten_buser_cut(self, info):
        
        i = self.shorten_buser_cut_helper(info)
        while i:
            delete = max(info[i])

            info.pop(i)
            
            val_to_index = self.make_D(info)

            a, b = map(int, val_to_index[delete][0])

            info[a].pop(b)
            info[a].pop(b % len(info[a]))
            
            i = self.shorten_buser_cut_helper(info)
        

    def buser_cut_shortest_path(self, graph, start):
        
        q = deque([start])
        vis = set([start])
        predecessor = dict()
        while q:
            x = q.popleft()

            for k in graph[x]:
                if not k in vis:
                    q.append(k)
                    vis.add(k)
                    predecessor[k] = x
                    
                    if k > start:
                        
                        path = []
                        while k != start:
                            path.append(k)
                            k = predecessor[k]
                        
                        path.append(k)
                        path.reverse()
                            
                        return path
        

    def one_cut_shortest_path(self, graph, start, end):
        
        q = deque([start])
        vis = set([start])
        predecessor = dict()
        while q:
            x = q.popleft()

            for (k, v) in graph[x]:
                if not k in vis:
                    q.append(k)
                    vis.add(k)
                    predecessor[k] = x
                    
                    if k == end:
                        
                        path = []
                        while k != start:
                            path.append(k)
                            k = predecessor[k]
                        
                        path.append(k)
                        path.reverse()
                            
                        return path

    
    # return true if surface has ≤1 boundary component
    # return false if surface has >1 boundary component
    # should never be the case that surface has <1 boundary component
    # Time complexity: O(1)
    def is_one_boundary_component(self, surface):
        return surface.unique_bc() == 1
                
    # tell is a surface is a pair of pants
    # return boolean
    # Time complexity: O(n)
    def is_pant(self, surface):
        return surface.unique_bc() == 3 and surface.genus() == 0
    
    # recursive algorithm to get number of cuts in a pants decomposition
    # this function should only trigger once for each pant and once for each cut. In total, it should only run 5g-5 times.
    # Time complexity: O(n) times the worst case subfunction
    def pants_decomposition(self, surface):
        
        
        # print("General cut result: {}".format(c))
        # print("The info: {}".format(surface.info))
        
        if self.is_pant(surface):
            return 0
        
        c = self.general_simple_cut(surface)
        
        if c:
            
            length = 1
            for s in c:
                length = max(self.pants_decomposition(s), length)
            return length
        
        if self.is_one_boundary_component(surface):

            c, length = self.one_boundary_cut(surface)
            for s in c:
                length = max(self.pants_decomposition(s), length)
            return length


        c, length = self.buser_cut(surface)
        for s in c:
            length = max(self.pants_decomposition(s), length)
        return length
    
    def pants_decomposition_for_all(self, surface):
        
        
        # print("General cut result: {}".format(c))
        # print("The info: {}".format(surface.info))
        
        if self.is_pant(surface):
            return 0, 0, [], 0
        
        c = self.general_simple_cut(surface)
        b = 0
        if c:
            l = 1
            all_cuts = [[0, 1]]
            max_length = l
            total_length = l
            for s in c:
                ml, tl, na, nb = self.pants_decomposition_for_all(s)
                b += nb
                all_cuts += na
                max_length = max(ml, max_length)
                total_length += tl
            return max_length, total_length, all_cuts, b
        
        if self.is_one_boundary_component(surface):

            c, l = self.one_boundary_cut(surface)
            max_length = l
            total_length = l
            all_cuts = [[1, l]]
            for s in c:
                ml, tl, na, nb = self.pants_decomposition_for_all(s)
                b += nb
                all_cuts += na
                max_length = max(ml, max_length)
                total_length += tl
            return max_length, total_length, all_cuts, b

        bcs = surface.actual_bc()
        c, l = self.buser_cut(surface)
        max_length = l
        total_length = l
        all_cuts = [[2, l]]
        b += 1
        for s in c:
            ml, tl, na, nb = self.pants_decomposition_for_all(s)
            b += nb
            all_cuts += na
            max_length = max(ml, max_length)
            total_length += tl
        return max_length, total_length, all_cuts, b
    
    
    def pants_decomposition_for_all_fake(self, surface):
        
        
        # print("General cut result: {}".format(c))
        # print("The info: {}".format(surface.info))
        
        if self.is_pant(surface):
            return 0, 0
        
        c = self.general_simple_cut(surface)
        
        if c:
            l = 1
            max_length = l
            total_length = l
            for s in c:
                ml, tl = self.pants_decomposition_for_all(s)
                max_length = max(ml, max_length)
                total_length += tl
            return max_length, total_length
        
        if self.is_one_boundary_component(surface):

            c, l = self.one_boundary_cut(surface)
            max_length = l
            total_length = l
            for s in c:
                ml, tl = self.pants_decomposition_for_all(s)
                max_length = max(ml, max_length)
                total_length += tl
            return max_length, total_length

        c, l = self.buser_cut(surface)
        max_length = l
        total_length = l
        for s in c:
            ml, tl = self.pants_decomposition_for_all(s)
            max_length = max(ml, max_length)
            total_length += tl
        return max_length, total_length
    
    def pants_decomposition_for_cuts(self, surface):
               
        if self.is_pant(surface):
            return 0
        
        cuts = 0
        
        c = self.general_simple_cut(surface)

        
        if c:
            
            for s in c:
                cuts += self.pants_decomposition_for_cuts(s)

            return cuts+1
        
        if self.is_one_boundary_component(surface):
            c, length = self.one_boundary_cut(surface)
            for s in c:
                cuts += self.pants_decomposition_for_cuts(s)
            return cuts+1
        
        c, length = self.buser_cut(surface)
        for s in c:
            cuts += self.pants_decomposition_for_cuts(s)
        return cuts + 1
    
    def pants_decomposition_for_n(self, surface):
        
        size = sum(len(x) for x in surface.info)
        
        if self.is_pant(surface):
            return size
        
        c = self.general_simple_cut(surface)
        
        if c:
            
            for s in c:
                size = max(self.pants_decomposition(s), size)
            return size
        
        if self.is_one_boundary_component(surface):

            c, length = self.one_boundary_cut(surface)
            for s in c:
                size = max(self.pants_decomposition(s), size)
            return size


        c, length = self.buser_cut(surface)
        for s in c:
            size = max(self.pants_decomposition(s), size)
        return size
    
if __name__ == '__main__':
    g = Pants_Decomposition()
    from random_combinatorial import *
    generator = Random_Combinatorial()

    
    def gen(func, mi, ma):
        s = func(random.randint(mi / 2, ma / 2) * 2)
        while s.genus() < 2:
            s = func(random.randint(mi / 2, ma / 2) * 2)
        return s
    
    s = gen(generator.generate_random_surface, 200, 300)
    
    print(s.genus())
    print(s.genus() * 4 - 4)
    print(g.pants_decomposition(s))