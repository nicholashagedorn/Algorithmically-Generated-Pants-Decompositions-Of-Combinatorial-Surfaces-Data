from surfaces import *

g = Pants_Decomposition()

def adjacent_tori(count):
    
    count = count // 4
    
    info = [[]]

    for i in range(1, count+1):
        info[0].append(2*i)
        info[0].append(2*i+1)
    for i in range(count, 0, -1):
        info[0].append(2*i)
        info[0].append(2*i+1)

    return Orientable_Bounded_Combinatorial(info, max(info[0]), 0)


def simple(count):
    count = count // 2
    
    info = [[]]
    
    for i in range(1, count+1, 2):
        info[0].append(i)
        info[0].append(i+1)
        info[0].append(i)
        info[0].append(i+1)
        
    return Orientable_Bounded_Combinatorial(info, max(info[0]), 0)