import surfaces_old
from random_combinatorial import *
from types_of_surfaces import *
from greedy_decomposition import *
import numpy as np
import random



generator = Random_Combinatorial()
g = surfaces_old.Pants_Decomposition()
greedy = Greedy_Decomposition()


def gen(func, mi, ma):
    s = func(random.randint(mi / 2, ma / 2) * 2)
    while s.genus() < 2:
        s = func(random.randint(mi / 2, ma / 2) * 2)
    return s


def output(func, mi, ma):
    s = gen(func, mi, ma)

    result = greedy.full_decomposition(s)
    
    print(result)
   
    # t.write(f"\n{s.genus()} {result[0]} {result[1]}")
    
with open('specific_graphs/linear_algorithm/i_vs_length_of_one_surface/seconddata.txt', 'a') as t:
    s = gen(generator.generate_random_surface, 408, 408)
    
    print(s.genus())
    print(s.genus() * 4 - 4)
    result = g.pants_decomposition_for_all(s)
    for i, l in enumerate(result[2]):
        t.write(f"\n{i+1} {l[1]}")