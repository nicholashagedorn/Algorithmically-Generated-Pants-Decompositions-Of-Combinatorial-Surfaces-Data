import matplotlib.pyplot as plt
import pandas as pd
import numpy as np


# data = open("data.txt", "r").read().split("\n\n")[2].split("\n")[1:]
data = open("specific_graphs/new_algorithm/genus_vs_length/data.txt", "r").read().split("\n")
print(max([list(map(int, x.split()))[0] for x in data]))

linear_data = open("specific_graphs/new_algorithm/genus_vs_length/linear_data.txt", "r").read().split("\n")

new_linear = []
for x in linear_data:
    if list(map(int, x.split()))[0] <= 74:
        print(x)
        new_linear.append(x)
    
        
print(data[:10])
print(new_linear[:10])
df = pd.DataFrame({'g': [list(map(int, x.split()))[0] for x in data], 'l': [list(map(int, x.split()))[1] for x in data]})
dl = pd.DataFrame({'g': [list(map(int, x.split()))[0] for x in new_linear], 'l': [list(map(int, x.split()))[1] for x in new_linear]})

plt.grid()

def total_length_reg(x):
    return 4*x - 4

x = np.linspace(0, 100, 100)
# plt.plot(x, total_length_reg(x), color='red')

model = np.poly1d(np.polyfit((df['g']), (df['l']), 1))
polyline = np.linspace(0, 500, 50)

plt.scatter((df['g']), (df['l']), alpha=0.4, color='blue', s=40)
# plt.scatter((df['g']), (2*np.log2(df['real'])+1), alpha=0.5, color='green', s=40)

# print(model)

    
# df.groupby("g")['l'].mean().p/lot()
# dl.groupby("g")['l'].mean().plot()
# df.groupby("g")['tl'].mean().plot()

# plt.plot(polyline, model(polyline), color = 'black', alpha=1)


plt.xlabel("Genus")
plt.ylabel("Average Length of Pants Decomposition")
plt.title("Average Pants Decomposition Length vs. Genus")

plt.show()

